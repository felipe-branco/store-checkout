import { Kiosk } from '@/components/kiosk/kiosk'

export default function Page() {
  return <Kiosk />
}
